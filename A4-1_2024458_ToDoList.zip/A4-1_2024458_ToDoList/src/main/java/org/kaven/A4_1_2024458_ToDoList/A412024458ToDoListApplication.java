package org.kaven.A4_1_2024458_ToDoList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A412024458ToDoListApplication {

	public static void main(String[] args) {
		SpringApplication.run(A412024458ToDoListApplication.class, args);
	}

}
