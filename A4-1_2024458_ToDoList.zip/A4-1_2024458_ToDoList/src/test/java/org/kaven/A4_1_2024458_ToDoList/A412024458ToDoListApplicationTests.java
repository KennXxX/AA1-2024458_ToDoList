package org.kaven.A4_1_2024458_ToDoList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A412024458ToDoListApplicationTests {

	@Test
	void contextLoads() {
	}

}
